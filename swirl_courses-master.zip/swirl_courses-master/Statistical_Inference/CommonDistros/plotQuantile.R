g <- g + geom_vline(xintercept = qnorm(.1), size = 3, colour="blue")
print(g)
