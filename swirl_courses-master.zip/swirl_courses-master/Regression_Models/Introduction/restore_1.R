plot(child ~ parent, galton)
